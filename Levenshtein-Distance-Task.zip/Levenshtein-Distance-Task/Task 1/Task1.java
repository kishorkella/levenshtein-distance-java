
import java.util.*;
public class Task1 {
    public static int editDistance(String s1, String s2) {
        int m = s1.length();
        int n = s2.length();
        int[][] dpArray = new int[m + 1][n + 1];

        for (int i = 0; i <= m; i++) {
            dpArray[i][0] = i;
        }
        for (int j = 0; j <= n; j++) {
            dpArray[0][j] = j;
        }

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                    dpArray[i][j] = dpArray[i - 1][j - 1];
                } else {
                    dpArray[i][j] = Math.min(
                            Math.min(dpArray[i - 1][j], dpArray[i][j - 1]),
                            dpArray[i - 1][j - 1]
                    ) + 1;
                }
            }
        }
        return dpArray[m][n];
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter string s1 :");
        String s1 = scan.next();
        System.out.print("Enter string s2 :");
        String s2 = scan.next();
        System.out.println("Task 1:");
        System.out.print("the minimum cost is : ");
        System.out.println(editDistance(s1, s2));
        //  memo = new int[s1.length() + 1][s2.length() + 1];//memorization
        // for (int[] row : memo) Arrays.fill(row, -1);
        // System.out.println(editDistanceMemo(s1, s2, s1.length(), s2.length()));

        scan.close();
    }
       static int[][] memo;

    public static int editDistanceMemo(String s1, String s2, int i, int j) {
        if (i == 0) return j;
        if (j == 0) return i;

        if (memo[i][j] != -1) return memo[i][j];

        if (s1.charAt(i - 1) == s2.charAt(j - 1))
            return memo[i][j] = editDistanceMemo(s1, s2, i - 1, j - 1);

        int insert = editDistanceMemo(s1, s2, i, j - 1);
        int delete = editDistanceMemo(s1, s2, i - 1, j);
        int replace = editDistanceMemo(s1, s2, i - 1, j - 1);

        return memo[i][j] = 1 + Math.min(Math.min(insert, delete), replace);
    }
}
