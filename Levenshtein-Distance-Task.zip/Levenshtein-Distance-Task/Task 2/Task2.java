import java.util.*;
public class Task2 {
    public static int editDistance(String s1, String s2, int Ci, int Cd, int Cs) {
        int m = s1.length();
        int n = s2.length();
        int[][] dp = new int[m + 1][n + 1];

        for (int i = 0; i <= m; i++) {
            dp[i][0] = i * Cd;
        }
        for (int j = 0; j <= n; j++) {
            dp[0][j] = j * Ci;
        }

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.min(
                            Math.min(dp[i - 1][j] + Cd, dp[i][j - 1] + Ci),
                            dp[i - 1][j - 1] + Cs
                    );
                }
            }
        }
        return dp[m][n];
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter string s1: ");
        String s1 = scan.next();
        System.out.print("Enter string s2: ");
        String s2 = scan.next();
        System.out.print("Enter insertion cost Ci: ");
        int Ci = scan.nextInt();
        System.out.print("Enter deletion cost Cd: ");
        int Cd = scan.nextInt();
        System.out.print("Enter substitution cost Cs: ");
        int Cs = scan.nextInt();

        System.out.println("Task 2:");
        System.out.println("The minimum weighted cost is: " + editDistance(s1, s2, Ci, Cd, Cs));//tABULATION

        //  memo = new int[s1.length() + 1][s2.length() + 1];//memorization
        // for (int[] row : memo) Arrays.fill(row, -1);
        // System.out.println("The minimum weighted cost using memoization is: " + editDistanceMemo(s1, s2, s1.length(), s2.length(), Ci, Cd, Cs));
        // scan.close();
    }

     static int[][] memo;

    public static int editDistanceMemo(String s1, String s2, int i, int j, int Ci, int Cd, int Cs) {
        if (i == 0) return j * Ci;
        if (j == 0) return i * Cd;

        if (memo[i][j] != -1) return memo[i][j];

        if (s1.charAt(i - 1) == s2.charAt(j - 1))
            return memo[i][j] = editDistanceMemo(s1, s2, i - 1, j - 1, Ci, Cd, Cs);

        int insert = editDistanceMemo(s1, s2, i, j - 1, Ci, Cd, Cs) + Ci;
        int delete = editDistanceMemo(s1, s2, i - 1, j, Ci, Cd, Cs) + Cd;
        int replace = editDistanceMemo(s1, s2, i - 1, j - 1, Ci, Cd, Cs) + Cs;

        return memo[i][j] = Math.min(Math.min(insert, delete), replace);
    }
}
